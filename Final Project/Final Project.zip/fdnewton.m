function [X,Y,niter]=fdnewton(f,fy,fyp,a,b,alpha,beta,n,tol)
% Use Newton's Method for solving a system of equations 
% (Algorithm 11.1.2) with functions myF (for F) and myJ 
% (for J_F) to be implemented below in this file

% At end, add boundary values to X and Y vectors, as in fdlinear.m


    h = (b-a)/(n+1); % step size
    x = a + h.*(0:n);
    Y = alpha+((beta-alpha)*(x-alpha))/(b-a);;
    Y_store = [Y; zeros(9, length(x))]
    sol = [];
    k = 1;

    while isempty(sol)
        
        F = myF(x, Y_store(k,:), f, h, alpha, beta);
        J = myJ(x, Y_store(k,:), fy, fyp, h, alpha, beta);
        
        S = solvesys(J,F, s,b,alpha, beta, n);
        if sum(abs((Y_store(k,:)+S)-Y_store(k,:))) < tol
            Y_store(k+1,1:length(S)) = Y_store(k,:)+S
            sol = Y
        else
            k = k + 1;
            Y_store(k,1:length(S)) = Y_store(k-1,:)+S
        end
    end
    niter = k;



function F=myF(x,y,f,h,alpha,beta)
% Use formulas and/or code for F(y) from Example 13.2.3
% FOllowing taken from class textbook, pgs 527-528
    n = length(x);
    F = zeros(1, n);
    xi = x(2:end-1);    
    yi = y(2:end-1);    % y_i
    yi_forw = y(3:end);    % y_{i+1}
    yi_back = y(1:end-2);  % y_{i-1}
    yprime_i = (yi_forw-yi_back)/(2*h); % centered difference / secant=tangent
    F = (yi_forw-2*yi+yi_back)/(h^2) - f(xi,yi,yprime_i); % 2nd order centered diff / 2nd derivative
    


function J=myJ(x,y,fy,fyp,h,alpha,beta)
% Use formulas for J_F(y) on p. 528 of text

% Note: in formulas, y_0 = alpha, y_{N+1} = beta
    n = length(x)-1;
    mainJ = zeros(1,length(1:n));
    upperJ = zeros(1,length(1:n-1));
    lowerJ = zeros(1,length(2:n));
    for j = 2:n-1
        -(2/(h^2)) - fy(x,y,(y(j+1)-y(j-1))/(2*h))
        mainJ(j) = -(2/(h^2)) - fy(x,y,(y(j+1)-y(j-1))/(2*h));
        if j < n-1
            upperJ(j) = 1/(h^2) - (1/(2*h))*fyp(x,y,(y(j+1)-y(j-1))/(2*h));
        end
        if j > 1
            lowerJ(j-1) = 1/(h^2) + (1/(2*h))*fyp(x,y,(y(j+1)-y(j-1))/(2*h))
        end
    end
    J = diag(upperJ, 1) + diag(mainJ) + diag(lowerJ, -1);
    
    
function S = solvesys(J,R,a,b,alpha,beta,n) % where J is a tridiagonal matrix
    
    S = zeros(1,length(R));
    mainJ = diag(J);
    upperJ = diag(J,1);
    lowerJ = diag(J,-1);
    
    % Gaussian Elimination for tridiagonal matrix
    for j = 1:n-1
        lowerJ(j) = lowerJ(j)/mainJ(j);
        mainJ(j+1) = mainJ(j+1) - (lowerJ(j)*upperJ(j));
    end

    for fs = 2:n
        R(fs) = R(fs)-(lowerJ(fs-1)*R(fs-1));
    end
    S(n) = R(n)/mainJ(n);
    for bs = (n-1):-1:1
        S(bs) = (R(bs) - (upperJ(bs)*S(bs+1)))/mainJ(bs);
    end

    % Forward and back substitution applied to resulting unit lower
    % triangular matrix

    for j = 1:n-1
        lowerJ(j) = lowerJ(j)/mainJ(j);
        mainJ(j+1) = mainJ(j+1) - (lowerJ(j)*upperJ(j));
    end


    for fs = 2:n
        R(fs) = R(fs)-(lowerJ(fs-1)*R(fs-1));
    end
    S(n) = R(n)/mainJ(n);
    for bs = (n-1):-1:1
        S(bs) = (R(bs) - (upperJ(bs)*S(bs+1)))/mainJ(bs);
    end
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        